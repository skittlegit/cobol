"""Batched M4 execution through ChatGPT-authenticated Codex Luna.

Only provider calls are replaced.  Materialization, baseline contexts, the
``RealToolLayer``, policy guards, verification, schema-v3 records, and scoring
remain the same implementation used by the earlier API path.  The Codex task
workspace contains only opaque aliases, detector-visible clauses/contexts, and
materialized source; benchmark labels and provenance never enter it.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import tempfile
import uuid
from collections.abc import Mapping, Sequence
from pathlib import Path, PurePosixPath
from typing import Any, Literal

from pydantic import BaseModel

from cobol_archaeologist.agent.policy import EVIDENCE_MINIMUMS
from cobol_archaeologist.eval.baselines import (
    RAG_CONTEXT_TYPES,
    RAG_RETRIEVAL_MODES,
    OracleSliceContext,
    PlainLLMContext,
    RetrievedRAGContext,
    plain_llm_context,
    rag_baseline_context,
)
from cobol_archaeologist.eval.codex_batch import (
    AGENT_HUNTS,
    CodexBaselineEnvelope,
    CodexBatchEnvelope,
    ParsedCodexEvents,
    allocate_tokens,
    authorize_codex_event_stream,
    bind_submitted_response,
    codex_environment_sha256,
    finalize_agent_case,
    parse_codex_events,
    sanitized_codex_environment,
    strict_codex_schema,
    validate_agent_envelope,
    validate_baseline_envelope,
)
from cobol_archaeologist.eval.codex_tool import ToolLogEntry
from cobol_archaeologist.eval.live import (
    AGENT_BUDGET,
    BASELINE_BUDGET,
    BASELINE_SYSTEM_IDS,
    INPUT_REVISION,
    MIN_AGENT_ABSTENTION_OBSERVATIONS,
    OUTPUT_DIR,
    ROOT,
    SCHEMA_VERSION,
    SPLIT,
    SYSTEM_IDS,
    TOOL_VERSION,
    _tool_layer,
    bounded_code_context,
    load_split,
    single_shot_record,
)
from cobol_archaeologist.eval.materialize import MaterializedSource, materialize
from cobol_archaeologist.eval.run import (
    CONFIG2_SMOKE_IDS,
    CONFIG2_SMOKE_SEED,
    REQUIRED_SMOKE_ROWS,
    RunManifest,
    assess_run_validity,
    infrastructure_failure,
    record_outcome,
    repository_commit,
    run_key,
    seeded_stratified_smoke,
)
from cobol_archaeologist.eval.schemas import EvaluationRecord
from cobol_archaeologist.model.prompt import HUNT_PROMPTS, AgentResponse
from cobol_archaeologist.model.verify import Entailer, default_entailer
from cobol_archaeologist.rag.search import RegulationSearch
from cobol_archaeologist.schemas import DriftInstance, RegulationClause

MODEL_ID = "gpt-5.6-luna"
REASONING_EFFORT = "low"
PROVIDER_ID = "chatgpt-codex-plus"
PROMPT_VERSION = "m4-live-codex-batch-v4"
DEFAULT_WSL_DISTRO = "Ubuntu"
DEFAULT_CODEX_BINARY = "/home/deepa/.local/bin/codex-x86_64-unknown-linux-musl"
DEFAULT_SUPPORT_BASE = "/home/deepa/.cache/cobol-archaeologist/codex-support"
DEFAULT_TASK_BASE = "/home/deepa/.cache/cobol-archaeologist/codex-tasks"
AGENT_BATCH_SIZE = 2
PLAIN_LLM_BATCH_SIZE = 5
RAG_BATCH_SIZE = 5
ORACLE_SLICE_BATCH_SIZE = 2
# T5.3 Amendment 1: `dense_rag` is retired as a runner identity; see
# `eval.live.SystemID` for the shared registry this mirrors.
SystemID = Literal[
    "agent",
    "plain_llm",
    "rag_dense",
    "rag_reranker",
    "oracle_slice",
]
RunMode = Literal["smoke", "pilot", "full"]


def batch_size_for(system_id: SystemID) -> int:
    return {
        "agent": AGENT_BATCH_SIZE,
        "plain_llm": PLAIN_LLM_BATCH_SIZE,
        "rag_dense": RAG_BATCH_SIZE,
        "rag_reranker": RAG_BATCH_SIZE,
        "oracle_slice": ORACLE_SLICE_BATCH_SIZE,
    }[system_id]


PILOT_IDS: tuple[str, ...] = (
    "drift_000001",
    "drift_000002",
    "drift_000003",
    "drift_000004",
    "drift_000005",
    "drift_000006",
    "drift_000007",
    "drift_000008",
    "drift_000009",
    "drift_000010",
    "drift_068667",
    "drift_075075",
    "drift_000012",
    "drift_000019",
    "drift_000011",
    "drift_106241",
    "drift_003896",
    "drift_024882",
    "drift_016555",
    "drift_000013",
    "drift_000014",
    "drift_076481",
    "drift_255807",
    "drift_000018",
    "drift_031462",
    "drift_548537",
    "drift_046343",
    "drift_035337",
    "drift_024379",
    "drift_052199",
    "drift_000015",
    "drift_110002",
    "drift_282357",
    "drift_110022",
    "drift_063579",
    "drift_611233",
    "drift_066224",
    "drift_063888",
    "drift_157934",
    "drift_071627",
)


class CodexTaskExecution(BaseModel):
    task_root: str
    parsed: ParsedCodexEvents
    stderr: str
    final_message: str
    tool_logs: list[ToolLogEntry]
    request_sha256: str
    event_stream_sha256: str
    tool_logs_sha256: str


def _canonical_hash(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(
            value,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()


def codex_request_sha256(
    *,
    prompt: str,
    schema: Mapping[str, Any],
    sources: Mapping[str, MaterializedSource],
    model_id: str,
    reasoning_effort: str,
    cli_arguments: Sequence[str],
    runtime_source_sha256: str,
    transport: Literal["wsl", "native"],
    authentication_identity_sha256: str,
    authorized_hunts: Sequence[str],
    task_root: str,
) -> str:
    """Bind the immutable request identity used by raw bundle markers."""

    return _canonical_hash(
        {
            "provider": "chatgpt-codex",
            "authentication": "ChatGPT",
            "authentication_identity_sha256": authentication_identity_sha256,
            "model_id": model_id,
            "reasoning_effort": reasoning_effort,
            "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
            "schema_sha256": _canonical_hash(schema),
            "source_sha256": {
                alias: source.source_sha256 for alias, source in sorted(sources.items())
            },
            "cli_arguments": [
                argument.replace(str(task_root), "<TASK_ROOT>")
                for argument in cli_arguments
            ],
            "environment_sha256": codex_environment_sha256(),
            "runtime_source_sha256": runtime_source_sha256,
            "transport": transport,
            "authorized_hunts": list(authorized_hunts),
        }
    )


class _ReplayDecisionModel:
    """One-response DecisionModel used by the existing baseline finalizer."""

    def __init__(self, response: AgentResponse, model_id: str = MODEL_ID) -> None:
        self.response = response
        self.model_id = model_id
        self.temperature = 0.0
        self.seed = None
        self._used = False

    def respond(
        self,
        *,
        system_prompt: str,
        question: str,
        transcript: list[dict],
    ) -> AgentResponse:
        if self._used:
            raise RuntimeError("batched baseline replay response already consumed")
        self._used = True
        return self.response


def _chunks[T](values: Sequence[T], size: int) -> list[list[T]]:
    return [list(values[index : index + size]) for index in range(0, len(values), size)]


def _tar_bytes(files: Mapping[str, bytes]) -> bytes:
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode="w") as archive:
        for name, content in sorted(files.items()):
            pure = PurePosixPath(name)
            if pure.is_absolute() or ".." in pure.parts:
                raise ValueError(f"unsafe task archive path {name!r}")
            info = tarfile.TarInfo(pure.as_posix())
            info.size = len(content)
            info.mode = 0o600
            archive.addfile(info, io.BytesIO(content))
    return stream.getvalue()


def _wsl(
    arguments: Sequence[str],
    *,
    distro: str,
    input_bytes: bytes | None = None,
    timeout: float = 120,
) -> subprocess.CompletedProcess[bytes]:
    command = (
        list(arguments)
        if sys.platform == "linux"
        else ["wsl", "-d", distro, "--", *arguments]
    )
    return subprocess.run(
        command,
        input=input_bytes,
        capture_output=True,
        check=False,
        timeout=timeout,
        env=sanitized_codex_environment(),
    )


def _require_ok(
    result: subprocess.CompletedProcess[bytes],
    action: str,
) -> None:
    if result.returncode:
        stderr = result.stderr.decode("utf-8", errors="replace")
        raise RuntimeError(f"{action} failed ({result.returncode}): {stderr}")


def _stage_archive(
    root: str,
    files: Mapping[str, bytes],
    *,
    distro: str,
) -> None:
    made = _wsl(["mkdir", "-p", root], distro=distro)
    _require_ok(made, f"create WSL directory {root}")
    extracted = _wsl(
        ["tar", "-xf", "-", "-C", root],
        distro=distro,
        input_bytes=_tar_bytes(files),
    )
    _require_ok(extracted, f"stage WSL directory {root}")


def _support_runtime_files() -> dict[str, bytes]:
    files: dict[str, bytes] = {
        "pyproject.toml": (ROOT / "pyproject.toml").read_bytes(),
    }
    for path in (ROOT / "src").rglob("*.py"):
        files[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for path in (ROOT / "vendor" / "tree-sitter-cobol").rglob("*"):
        if path.is_file():
            files[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    return files


def _support_runtime_manifest(identity: str) -> bytes:
    files = _support_runtime_files()
    return json.dumps(
        {
            "schema_version": "1",
            "identity": identity,
            "files": {
                name: hashlib.sha256(payload).hexdigest()
                for name, payload in sorted(files.items())
            },
        },
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def _verify_support_runtime(
    *, support_root: str, expected_identity: str, distro: str
) -> None:
    script = (
        "import hashlib,json,pathlib,sys;"
        "r=pathlib.Path(sys.argv[1]);b=(r/'.runtime-manifest.json').read_bytes();"
        "assert hashlib.sha256(b).hexdigest()==sys.argv[3];m=json.loads(b);"
        "assert m['identity']==sys.argv[2];"
        "assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h "
        "for p,h in m['files'].items())"
    )
    verified = _wsl(
        [
            "python3",
            "-c",
            script,
            support_root,
            expected_identity,
            hashlib.sha256(_support_runtime_manifest(expected_identity)).hexdigest(),
        ],
        distro=distro,
    )
    _require_ok(verified, "verify pinned WSL support runtime")


def prepare_support_runtime(
    *,
    commit: str,
    distro: str = DEFAULT_WSL_DISTRO,
    support_base: str = DEFAULT_SUPPORT_BASE,
) -> str:
    """Build a data-free Python support environment keyed to the run commit."""

    if not commit or any(character not in "0123456789abcdef" for character in commit):
        raise ValueError("support runtime commit must be lowercase hexadecimal")
    support_root = f"{support_base}/{commit}"
    files = _support_runtime_files()
    manifest = _support_runtime_manifest(commit)
    files[".runtime-manifest.json"] = manifest
    marker = f"{support_root}/.ready"
    ready = _wsl(["test", "-f", marker], distro=distro)
    if ready.returncode == 0:
        _verify_support_runtime(
            support_root=support_root, expected_identity=commit, distro=distro
        )
        return support_root
    _stage_archive(support_root, files, distro=distro)

    uv = "/home/deepa/.local/bin/uv"
    venv = _wsl(
        [
            uv,
            "venv",
            "--python",
            "3.12",
            "--allow-existing",
            "--seed",
            f"{support_root}/.venv",
        ],
        distro=distro,
        timeout=300,
    )
    _require_ok(venv, "create isolated WSL support venv")
    installed = _wsl(
        [
            uv,
            "pip",
            "install",
            "--python",
            f"{support_root}/.venv/bin/python",
            "-e",
            support_root,
            "setuptools>=68",
        ],
        distro=distro,
        timeout=600,
    )
    _require_ok(installed, "install isolated WSL support package")
    grammar = _wsl(
        [
            f"{support_root}/.venv/bin/python",
            "-c",
            (
                "from cobol_archaeologist.parser._grammar "
                "import get_language; get_language()"
            ),
        ],
        distro=distro,
        timeout=600,
    )
    _require_ok(grammar, "build pinned WSL COBOL grammar")
    marked = _wsl(["touch", marker], distro=distro)
    _require_ok(marked, "mark WSL support runtime ready")
    _verify_support_runtime(
        support_root=support_root, expected_identity=commit, distro=distro
    )
    return support_root


def codex_exec_arguments(
    *,
    codex_binary: str,
    task_root: str,
    model_id: str,
    reasoning_effort: str,
    allow_tool_bridge: bool = True,
) -> list[str]:
    """Return the auditable no-API-key Codex invocation."""

    return [
        "env",
        "-i",
        "HOME=/home/deepa",
        "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "LANG=C.UTF-8",
        "TERM=dumb",
        codex_binary,
        "exec",
        "--json",
        "--ephemeral",
        "--ignore-user-config",
        "--ignore-rules",
        "--skip-git-repo-check",
        "--sandbox",
        "workspace-write" if allow_tool_bridge else "read-only",
        "-m",
        model_id,
        "-c",
        f'model_reasoning_effort="{reasoning_effort}"',
        "--output-schema",
        f"{task_root}/output_schema.json",
        "-o",
        f"{task_root}/final.json",
        "-C",
        task_root,
        "-",
    ]


def _check_chatgpt_login(
    *,
    codex_binary: str,
    distro: str,
) -> str:
    result = _wsl([codex_binary, "login", "status"], distro=distro)
    _require_ok(result, "check Codex login")
    status = "\n".join(
        text
        for text in (
            result.stdout.decode("utf-8", errors="replace").strip(),
            result.stderr.decode("utf-8", errors="replace").strip(),
        )
        if text
    )
    if "ChatGPT" not in status:
        raise RuntimeError(
            "Codex must be logged in through ChatGPT; API-key auth is refused"
        )
    return status


def _wsl_chatgpt_account_sha256(*, distro: str) -> str:
    """Return only a hash of the account-specific id in WSL Codex auth state."""

    script = (
        "import hashlib,json,os,pathlib;"
        "p=pathlib.Path(os.environ.get('CODEX_HOME',pathlib.Path.home()/'.codex'))/"
        "'auth.json';d=json.loads(p.read_text());"
        "a=d.get('tokens',{}).get('account_id');"
        "assert d.get('auth_mode')=='chatgpt' and isinstance(a,str) and a;"
        "print(hashlib.sha256(a.encode()).hexdigest())"
    )
    result = _wsl(["python3", "-c", script], distro=distro)
    _require_ok(result, "read account-specific WSL ChatGPT identity")
    identity = result.stdout.decode("utf-8", errors="replace").strip()
    if len(identity) != 64 or any(
        character not in "0123456789abcdef" for character in identity
    ):
        raise RuntimeError("WSL ChatGPT account identity is malformed")
    return identity


def build_agent_prompt(
    cases: Sequence[dict[str, Any]],
    *,
    tool_command: str,
) -> str:
    """Build a label-free multi-hunt prompt over opaque case aliases."""

    visible = json.dumps(list(cases), ensure_ascii=False, separators=(",", ":"))
    hunt_guide = "\n".join(f"- {hunt}: {HUNT_PROMPTS[hunt]}" for hunt in AGENT_HUNTS)
    return f"""\
You are the M4 COBOL compliance agent under evaluation. Investigate every
opaque case below against its supplied regulation clause. Hidden benchmark
labels, generation history, and scoring data are not available and must not be
inferred.

For source evidence, use only this bounded real-tool command:
  {tool_command} ALIAS HUNT TOOL --arguments 'JSON_OBJECT'
Exact TOOL argument objects are: read_program {{"program":"..."}};
read_paragraph {{"program":"...","name":"..."}}; find_callers and
find_callees {{"program":"...","para":"..."}}; trace_variable and slice_on
{{"var":"...","program":"..."}} (program optional); resolve_copybook
{{"name":"..."}}; get_data_layout {{"record":"..."}}; grep {{"pattern":"..."}};
run_cobol {{"snippet":"...","inputs":null}}; search_regulations
{{"query":"..."}}.
Each D1-D7 HUNT has an independent transcript and an independent maximum of 8
tool calls. Use the exact class name as HUNT; there is no shared hunt. Obtain
at least 3 successful bounded observations for each hunt before emitting a
finding. Do not read case files directly and do not inspect parent directories,
git history, file timestamps, comments-as-edit-cues, formatting
discontinuities, or identifier style. Prefer read_program, grep, relevant
read_paragraph calls, and only the slice/call-graph/copybook tools required by
that hunt's evidence contract. For D2, reserve calls for grep, find_callers,
find_callees, and slice_on, and emit only when all four observations are
negative.

Return exactly one result for every alias. Each result has the seven required
D1_stale_threshold through D7_conformant response keys shown by the schema.
The host attaches the case identity and supplied clause to a
finding; author the remaining prediction fields, cite concrete original-source
loci, and include verifier hooks. The separate claim is the citation
hypothesis: write only a regulatory obligation entailed by the supplied clause,
without COBOL identifiers or implementation facts. Put the code-versus-clause
comparison in prediction.rationale and final_answer. Abstain when the
class-specific evidence is incomplete.
In a locus, program names the containing executable program and file names the
physical copybook/source filename, never an absolute task path. Set
is_interprocedural=true whenever loci carry more than one distinct program
name; cross-paragraph or copybook-spanning loci may also be interprocedural.
For D1 or D5 against a clause whose current_value is composite, target_path
must name a non-composite leaf from that supplied value.
"Searched and found nothing" is D2 or abstention, never conformant.
D7 is not a default verdict: it requires positive source evidence that the implemented
literal/comparator matches the clause. D6 supplies dead_paragraph evidence and
delegates reachability to the verifier. Do not emit explanations outside the
required JSON schema. Before submitting, parse the complete final in your
working context and check it against the supplied schema. In particular,
remove dangling commas and reject malformed JSON rather than emitting it.

Frozen hunt instructions:
{hunt_guide}

Evidence-hook requirements: D1 supplies a source literal and compares it with
the resolved current-value leaf; D2 supplies typed insertion lines and evidence
from the relevant paragraph, scoped grep, and data slice; D3 supplies a typed
contradictory source locus and a static hook, using multiple paragraph reads
when the contradiction is internal; D4 resolves a copybook and names a
missing/extra enum value; D5 supplies a typed source comparator and explains
the resulting branch boundary; D6 supplies a read paragraph plus either
dead_paragraph or a disabled-guard literal; D7 uses conformant labels with no
drift lines plus positive literal/comparator evidence.
For every non-null static hook, `static_claim.literal` and
`static_claim.comparator` are exact substrings copied from a cited tool
observation; they are source tokens, not explanations. Positive:
{{"literal":"7","comparator":">="}}. Negative:
{{"comparator":"source `>=`; clause `at_most`"}}. Put that comparison in
prediction.rationale instead.

Detector-visible cases:
{visible}
"""


def build_baseline_prompt(
    system_id: SystemID,
    cases: Sequence[dict[str, Any]],
) -> str:
    if system_id not in BASELINE_SYSTEM_IDS:
        raise ValueError(
            f"baseline prompt requires one of {', '.join(BASELINE_SYSTEM_IDS)}"
        )
    clause_selection = (
        "For a finding, set clause_index to the zero-based index of the "
        "supporting clause in context.retrieved_clauses. The host validates "
        "that selection and attaches that exact detector-visible clause."
        if system_id in RAG_RETRIEVAL_MODES
        else (
            "Set clause_index to null. The host attaches the single "
            "detector-visible context.clause."
        )
    )
    visible = json.dumps(list(cases), ensure_ascii=False, separators=(",", ":"))
    return f"""\
Perform one evidence-grounded COBOL compliance classification for each opaque
case using only its supplied {system_id} context. Tools and file access are not
available. Return exactly one response per alias under the required JSON
schema. A finding must use the alias as prediction.instance_id, copy the
schema. {clause_selection}
The host also attaches the case identity; author the remaining prediction
fields, cite concrete source loci from the context, and include verifier hooks.
The separate claim is the citation hypothesis: write only a regulatory
obligation entailed by the selected visible clause, without COBOL identifiers
or implementation facts. Put the code-versus-clause comparison in
prediction.rationale and final_answer. In a locus, program names the containing
executable program and file names the physical copybook/source filename, never
an absolute task path. Set target_path to null unless a D1 or D5 finding
targets a composite current_value; in that case it must name a non-composite
leaf from the selected visible clause. D7 requires positive source evidence of
conformance and is never a default verdict. Abstain when evidence is
insufficient. Do not use or infer hidden labels, generation provenance,
mutation metadata, git history, file timestamps, formatting, comment
freshness, or identifier style.

Detector-visible cases:
{visible}
"""


def _baseline_context(
    system_id: SystemID,
    payload: Mapping[str, Any],
) -> PlainLLMContext | RetrievedRAGContext | OracleSliceContext:
    """Revalidate a persisted context under its own runner identity's shape."""

    if system_id in RAG_RETRIEVAL_MODES:
        return RAG_CONTEXT_TYPES[system_id].model_validate(payload)
    if system_id == "plain_llm":
        return PlainLLMContext.model_validate(payload)
    if system_id == "oracle_slice":
        return OracleSliceContext.model_validate(payload)
    raise ValueError(f"unsupported baseline system {system_id}")


def select_baseline_clause(
    system_id: SystemID,
    clause_index: int | None,
    context: PlainLLMContext | RetrievedRAGContext | OracleSliceContext,
) -> RegulationClause:
    """Bind a baseline finding only to a clause visible in its own context."""

    if system_id in RAG_RETRIEVAL_MODES:
        expected_rag = RAG_CONTEXT_TYPES[system_id]
        if not isinstance(context, expected_rag):
            raise TypeError(f"{system_id} requires {expected_rag.__name__}")
        if clause_index is None:
            raise ValueError(f"{system_id} finding requires clause_index")
        if clause_index < 0:
            raise ValueError(f"{system_id} clause_index must be non-negative")
        try:
            return context.retrieved_clauses[clause_index].clause
        except IndexError as exc:
            raise ValueError(
                f"{system_id} clause_index {clause_index} is outside "
                f"{len(context.retrieved_clauses)} visible retrievals"
            ) from exc
    # plain_llm and oracle_slice each see exactly one clause, so an index would
    # be a selection they were never offered.
    single: dict[str, type[PlainLLMContext | OracleSliceContext]] = {
        "plain_llm": PlainLLMContext,
        "oracle_slice": OracleSliceContext,
    }
    expected_single = single.get(system_id)
    if expected_single is not None:
        if not isinstance(context, expected_single):
            raise TypeError(f"{system_id} requires {expected_single.__name__}")
        if clause_index is not None:
            raise ValueError(f"{system_id} clause_index must be null")
        return context.clause
    raise ValueError(f"unsupported baseline system {system_id}")


def _stage_task(
    *,
    prompt: str,
    schema: dict[str, Any],
    sources: Mapping[str, MaterializedSource],
    distro: str,
    task_base: str,
    ablation_runtime: Mapping[str, Any] | None = None,
) -> str:
    task_id = uuid.uuid4().hex
    task_root = f"{task_base}/{task_id}"
    descriptor: dict[str, Any] = {"aliases": {}}
    if ablation_runtime is not None:
        descriptor["ablation_runtime"] = dict(ablation_runtime)
    files: dict[str, bytes] = {
        "prompt.txt": prompt.encode(),
        "output_schema.json": json.dumps(schema, sort_keys=True).encode(),
    }
    for alias, source in sources.items():
        descriptor["aliases"][alias] = {"source_dir": f"cases/{alias}"}
        for filename, text in source.files.items():
            pure = PurePosixPath(filename)
            if pure.is_absolute() or ".." in pure.parts:
                raise ValueError(f"unsafe materialized filename {filename!r}")
            files[f"cases/{alias}/{pure.as_posix()}"] = text.encode()
    files["descriptor.json"] = json.dumps(descriptor, sort_keys=True).encode()
    _stage_archive(task_root, files, distro=distro)
    return task_root


def _read_wsl_file(path: str, *, distro: str, required: bool = True) -> str:
    result = _wsl(["cat", path], distro=distro)
    if result.returncode:
        if required:
            _require_ok(result, f"read WSL file {path}")
        return ""
    return result.stdout.decode("utf-8", errors="replace")


def execute_codex_task(
    *,
    prompt: str,
    schema: dict[str, Any],
    sources: Mapping[str, MaterializedSource],
    support_root: str,
    distro: str = DEFAULT_WSL_DISTRO,
    task_base: str = DEFAULT_TASK_BASE,
    codex_binary: str = DEFAULT_CODEX_BINARY,
    model_id: str = MODEL_ID,
    reasoning_effort: str = REASONING_EFFORT,
    timeout_s: float = 900,
    runtime_source_sha256: str | None = None,
    authentication_identity_sha256: str | None = None,
    authorized_hunts: Sequence[str] = AGENT_HUNTS,
    ablation_runtime: Mapping[str, Any] | None = None,
) -> CodexTaskExecution:
    """Stage and execute one isolated, replayable ChatGPT Codex task."""

    task_root = _stage_task(
        prompt=prompt,
        schema=schema,
        sources=sources,
        distro=distro,
        task_base=task_base,
        ablation_runtime=ablation_runtime,
    )
    arguments = codex_exec_arguments(
        codex_binary=codex_binary,
        task_root=task_root,
        model_id=model_id,
        reasoning_effort=reasoning_effort,
        allow_tool_bridge=bool(sources),
    )
    runtime_identity = runtime_source_sha256 or Path(support_root).name
    _verify_support_runtime(
        support_root=support_root, expected_identity=runtime_identity, distro=distro
    )
    request_hash = codex_request_sha256(
        prompt=prompt,
        schema=schema,
        sources=sources,
        model_id=model_id,
        reasoning_effort=reasoning_effort,
        cli_arguments=arguments,
        runtime_source_sha256=runtime_identity,
        transport="wsl",
        authentication_identity_sha256=(
            authentication_identity_sha256
            or hashlib.sha256(b"ChatGPT-status-not-supplied").hexdigest()
        ),
        authorized_hunts=authorized_hunts,
        task_root=task_root,
    )
    if authentication_identity_sha256 is None:
        raise RuntimeError("Codex task requires a frozen ChatGPT account identity")
    if _wsl_chatgpt_account_sha256(distro=distro) != authentication_identity_sha256:
        raise RuntimeError("ChatGPT account changed before WSL provider invocation")
    result = _wsl(
        arguments,
        distro=distro,
        input_bytes=prompt.encode(),
        timeout=timeout_s,
    )
    stderr = result.stderr.decode("utf-8", errors="replace")
    if result.returncode:
        stdout = result.stdout.decode("utf-8", errors="replace")
        detail = "\n".join(part for part in (stderr, stdout) if part).strip()
        raise RuntimeError(
            f"Codex task failed ({result.returncode}) at {task_root}: {detail[-4000:]}"
        )
    stdout = result.stdout.decode("utf-8", errors="replace")
    parsed = parse_codex_events(stdout)
    tool_command = (
        f"{support_root}/.venv/bin/python -m cobol_archaeologist.eval.codex_tool"
        if sources
        else None
    )
    tool_logs, event_hash = authorize_codex_event_stream(
        parsed,
        tool_command=tool_command,
        allowed_aliases=sources,
        allowed_hunts=authorized_hunts,
    )
    execution = CodexTaskExecution(
        task_root=task_root,
        parsed=parsed,
        stderr=stderr,
        final_message=parsed.final_message,
        tool_logs=tool_logs,
        request_sha256=request_hash,
        event_stream_sha256=event_hash,
        tool_logs_sha256=_canonical_hash(
            [entry.model_dump(mode="json") for entry in tool_logs]
        ),
    )
    normalized_base = task_base.rstrip("/") + "/"
    if not task_root.startswith(normalized_base) or task_root == task_base.rstrip("/"):
        raise RuntimeError("refusing to clean an unexpected WSL task directory")
    cleaned = _wsl(["rm", "-rf", "--", task_root], distro=distro)
    _require_ok(cleaned, f"clean WSL task directory {task_root}")
    return execution


def _extract_context(question: str) -> dict[str, Any]:
    marker = "Visible context (JSON):\n"
    suffix = "\nReturn one finding or abstain. Tool calls are not available."
    if marker not in question or not question.endswith(suffix):
        raise ValueError("prior baseline question has an unknown context envelope")
    return json.loads(question.split(marker, 1)[1][: -len(suffix)])


def load_reusable_baseline_contexts(
    system_id: SystemID,
    *,
    source_shas: Mapping[str, str],
    artifact_dir: Path = ROOT / "data" / "eval" / "legacy" / "m4-initial",
) -> dict[str, dict[str, Any]]:
    """Reuse only deterministic, source-hash-matched contexts from API runs."""

    if system_id not in BASELINE_SYSTEM_IDS:
        raise ValueError("only baseline contexts are reusable")
    path = Path(artifact_dir) / f"{system_id}.jsonl"
    contexts: dict[str, dict[str, Any]] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        instance_id = record["instance_id"]
        if record["source_sha256"] != source_shas.get(instance_id):
            continue
        trajectory = record.get("trajectory")
        if not trajectory:
            continue
        contexts[instance_id] = _extract_context(trajectory["question"])
    missing = sorted(set(source_shas) - set(contexts))
    if missing:
        raise RuntimeError(
            "reusable baseline contexts are missing or source-stale for "
            f"{len(missing)} row(s): {', '.join(missing[:3])}"
        )
    return contexts


def _mode_rows(
    rows: Sequence[DriftInstance],
    mode: RunMode,
    *,
    smoke_seed: int,
) -> list[DriftInstance]:
    if smoke_seed != CONFIG2_SMOKE_SEED:
        raise ValueError(
            f"the pinned config-2 smoke seed is {CONFIG2_SMOKE_SEED}, not {smoke_seed}"
        )
    if mode == "smoke":
        selected = seeded_stratified_smoke(rows, seed=smoke_seed)
        selected_ids = tuple(row.instance_id for row in selected)
        if selected_ids != CONFIG2_SMOKE_IDS:
            raise ValueError(
                "the frozen split no longer reproduces the pinned config-2 "
                f"smoke IDs: {selected_ids}"
            )
        return selected
    if mode == "pilot":
        by_id = {row.instance_id: row for row in rows}
        missing = [instance_id for instance_id in PILOT_IDS if instance_id not in by_id]
        if missing:
            raise ValueError(f"pilot IDs missing from split: {missing}")
        return [by_id[instance_id] for instance_id in PILOT_IDS]
    return list(rows)


def _assert_clean_runtime_source() -> None:
    scope = ("src/cobol_archaeologist", "pyproject.toml")
    dirty: list[str] = []
    for cached in (False, True):
        command = ["git", "diff", "--name-only", "--ignore-cr-at-eol"]
        if cached:
            command.append("--cached")
        command.extend(("--", *scope))
        result = subprocess.run(
            command,
            cwd=ROOT,
            capture_output=True,
            check=True,
            text=True,
        )
        dirty.extend(line for line in result.stdout.splitlines() if line)
    untracked = subprocess.run(
        [
            "git",
            "ls-files",
            "--others",
            "--exclude-standard",
            "--",
            *scope,
        ],
        cwd=ROOT,
        capture_output=True,
        check=True,
        text=True,
    )
    dirty.extend(line for line in untracked.stdout.splitlines() if line)
    if dirty:
        raise RuntimeError(
            "Codex M4 execution requires committed runtime source; "
            "commit or remove the listed changes first:\n"
            + "\n".join(sorted(set(dirty)))
        )


def _artifact_dir(output_dir: Path, mode: RunMode) -> Path:
    return Path(output_dir) / ("smoke" if mode == "smoke" else mode)


def _manifest(
    *,
    system_id: SystemID,
    mode: RunMode,
    rows: Sequence[DriftInstance],
    commit: str,
    cli_version: str,
    smoke_seed: int,
    smoke_instance_ids: Sequence[str],
) -> RunManifest:
    budget = AGENT_BUDGET if system_id == "agent" else BASELINE_BUDGET
    return RunManifest(
        system_id=system_id,
        provider=PROVIDER_ID,
        model_id=MODEL_ID,
        decoding={
            "reasoning_effort": REASONING_EFFORT,
            "temperature_parameter": "not_exposed_by_codex_cli",
            "seed": None,
            "authentication": "ChatGPT",
            "codex_cli_version": cli_version,
            "batch_size": batch_size_for(system_id),
            **(
                {"min_successful_observations_by_drift_type": dict(EVIDENCE_MINIMUMS)}
                if system_id == "agent"
                else {}
            ),
        },
        budgets=budget.model_dump(mode="json"),
        repository_commit=commit,
        input_revision=INPUT_REVISION,
        tool_version=f"{TOOL_VERSION}@{commit}",
        prompt_version=PROMPT_VERSION,
        split_path=SPLIT.relative_to(ROOT).as_posix(),
        split_sha256=hashlib.sha256(SPLIT.read_bytes()).hexdigest(),
        schema_version=SCHEMA_VERSION,
        run_mode=mode,
        smoke_rows=REQUIRED_SMOKE_ROWS if mode == "smoke" else None,
        smoke_seed=smoke_seed,
        smoke_instance_ids=list(smoke_instance_ids),
        total=len(rows),
    )


def _assert_prerequisite(
    expected: RunManifest,
    *,
    output_dir: Path,
    mode: Literal["smoke", "pilot"],
) -> None:
    path = _artifact_dir(output_dir, mode) / f"{expected.system_id}.manifest.json"
    if not path.exists():
        raise RuntimeError(f"{mode} prerequisite is missing: {path}")
    prior = RunManifest.model_validate_json(path.read_text(encoding="utf-8"))
    fields = (
        "system_id",
        "provider",
        "model_id",
        "decoding",
        "budgets",
        "repository_commit",
        "input_revision",
        "tool_version",
        "prompt_version",
        "split_path",
        "split_sha256",
        "schema_version",
        "smoke_seed",
        "smoke_instance_ids",
    )
    mismatches = [
        field for field in fields if getattr(prior, field) != getattr(expected, field)
    ]
    required_total = REQUIRED_SMOKE_ROWS if mode == "smoke" else len(PILOT_IDS)
    valid = (
        prior.run_mode == mode
        and prior.total == required_total
        and len(prior.completed_run_keys) == required_total
        and not prior.infrastructure_failures
        and prior.validity is not None
        and prior.validity.status == "VALID"
        and prior.validity.completed_rows == required_total
    )
    if mismatches or not valid:
        detail = (
            f"mismatched fields: {', '.join(mismatches)}"
            if mismatches
            else "manifest is incomplete or not VALID"
        )
        raise RuntimeError(f"{mode} prerequisite failed: {detail}")


def _key(
    row: DriftInstance,
    source: MaterializedSource,
    *,
    system_id: SystemID,
    manifest: RunManifest,
) -> str:
    return run_key(
        instance_id=row.instance_id,
        source_sha256=source.source_sha256,
        system_id=system_id,
        model_id=manifest.model_id,
        budgets=manifest.budgets,
        prompt_version=manifest.prompt_version,
        tool_version=manifest.tool_version,
        commit=manifest.repository_commit,
        schema_version=manifest.schema_version,
    )


def _load_existing(path: Path) -> dict[str, EvaluationRecord]:
    if not path.exists():
        return {}
    records = [
        EvaluationRecord.model_validate_json(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    by_key = {record.run_key: record for record in records}
    if len(by_key) != len(records):
        raise ValueError(f"{path} contains duplicate run keys")
    return by_key


def _write_manifest(
    manifest: RunManifest,
    records: Sequence[EvaluationRecord],
    path: Path,
) -> None:
    manifest.completed_run_keys = sorted(record.run_key for record in records)
    manifest.infrastructure_failures = {
        record.instance_id: record.infrastructure_error
        for record in records
        if record.infrastructure_error
    }
    manifest.validity = assess_run_validity(records, system_id=manifest.system_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(manifest.model_dump_json(indent=2), encoding="utf-8")


def _persist_raw(
    execution: CodexTaskExecution,
    *,
    artifact_dir: Path,
    system_id: SystemID,
    batch_index: int,
) -> None:
    raw_dir = artifact_dir / "raw"
    raw_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{system_id}-{batch_index:04d}"
    (raw_dir / f"{stem}.events.jsonl").write_text(
        "\n".join(
            json.dumps(event, ensure_ascii=False) for event in execution.parsed.events
        )
        + "\n",
        encoding="utf-8",
    )
    (raw_dir / f"{stem}.meta.json").write_text(
        json.dumps(
            {
                "task_root": execution.task_root,
                "usage": execution.parsed.usage.model_dump(mode="json"),
                "thread_id": execution.parsed.thread_id,
                "stderr": execution.stderr,
                "tool_calls": len(execution.tool_logs),
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def run_codex_system(
    system_id: SystemID,
    *,
    rows: Sequence[DriftInstance],
    mode: RunMode,
    smoke_seed: int,
    output_dir: Path = OUTPUT_DIR / "chatgpt-luna",
    entailer: Entailer | None = None,
    regulation_search: RegulationSearch | None = None,
    distro: str = DEFAULT_WSL_DISTRO,
    codex_binary: str = DEFAULT_CODEX_BINARY,
) -> list[EvaluationRecord]:
    """Run one resumable M4 system with fresh Luna outputs and trusted guards."""

    if system_id not in SYSTEM_IDS:
        raise ValueError(f"unknown M4 system {system_id!r}")
    _assert_clean_runtime_source()
    smoke_rows = _mode_rows(rows, "smoke", smoke_seed=smoke_seed)
    run_rows = (
        smoke_rows if mode == "smoke" else _mode_rows(rows, mode, smoke_seed=smoke_seed)
    )
    smoke_instance_ids = tuple(row.instance_id for row in smoke_rows)
    commit = repository_commit(ROOT)
    support_root = prepare_support_runtime(commit=commit, distro=distro)
    login = _check_chatgpt_login(codex_binary=codex_binary, distro=distro)
    account_identity = _wsl_chatgpt_account_sha256(distro=distro)
    version_result = _wsl([codex_binary, "--version"], distro=distro)
    _require_ok(version_result, "read Codex CLI version")
    cli_version = version_result.stdout.decode("utf-8", errors="replace").strip()
    if "ChatGPT" not in login:
        raise RuntimeError("ChatGPT Codex login check failed")

    manifest = _manifest(
        system_id=system_id,
        mode=mode,
        rows=run_rows,
        commit=commit,
        cli_version=cli_version,
        smoke_seed=smoke_seed,
        smoke_instance_ids=smoke_instance_ids,
    )
    if mode in {"pilot", "full"}:
        _assert_prerequisite(
            manifest,
            output_dir=Path(output_dir),
            mode="smoke",
        )
    if mode == "full":
        _assert_prerequisite(
            manifest,
            output_dir=Path(output_dir),
            mode="pilot",
        )
    materialized = {row.instance_id: materialize(row) for row in run_rows}
    source_shas = {
        instance_id: source.source_sha256
        for instance_id, source in materialized.items()
    }
    if system_id == "plain_llm":
        # Amendment 1: plain_llm is a new provider run and has no reusable M4
        # context. Build only its declared clause-plus-bounded-code context.
        contexts = {
            row.instance_id: plain_llm_context(
                row.regulation_clause,
                program=bounded_code_context(
                    materialized[row.instance_id], row.regulation_clause.text
                ),
            ).model_dump(mode="json")
            for row in run_rows
        }
    elif system_id == "rag_dense":
        if regulation_search is None:
            regulation_search = RegulationSearch(mode="dense")
        contexts = {
            row.instance_id: rag_baseline_context(
                system_id,
                row.regulation_clause.text,
                program=bounded_code_context(
                    materialized[row.instance_id], row.regulation_clause.text
                ),
                search=regulation_search,
            ).model_dump(mode="json")
            for row in run_rows
        }
    elif system_id == "agent":
        contexts = {}
    else:
        contexts = load_reusable_baseline_contexts(
            system_id,
            source_shas=source_shas,
        )
    artifact_dir = _artifact_dir(Path(output_dir), mode)
    records_path = artifact_dir / f"{system_id}.jsonl"
    manifest_path = artifact_dir / f"{system_id}.manifest.json"
    existing = _load_existing(records_path)
    records: list[EvaluationRecord] = []
    pending: list[DriftInstance] = []
    keys: dict[str, str] = {}
    for row in run_rows:
        key = _key(
            row,
            materialized[row.instance_id],
            system_id=system_id,
            manifest=manifest,
        )
        keys[row.instance_id] = key
        if key in existing:
            records.append(existing[key])
        else:
            pending.append(row)

    # DECISION (X5): the representative sample identity is durable before
    # execute_codex_task can produce any outcome used to judge config 2.
    _write_manifest(manifest, records, manifest_path)
    batch_size = batch_size_for(system_id)
    entailer = entailer or default_entailer()
    records_path.parent.mkdir(parents=True, exist_ok=True)
    with records_path.open("a", encoding="utf-8", newline="\n") as stream:
        work_queue = [(batch, 0) for batch in _chunks(pending, batch_size)]
        batch_index = 0
        while work_queue:
            batch, repair_attempt = work_queue.pop(0)
            batch_index += 1
            aliases = [f"drift_{900000 + index:06d}" for index in range(len(batch))]
            alias_rows = dict(zip(aliases, batch, strict=True))
            try:
                if system_id == "agent":
                    visible = [
                        {
                            "alias": alias,
                            "program_scope": (Path(row.provenance.base_program).stem),
                            "clause": row.regulation_clause.model_dump(mode="json"),
                        }
                        for alias, row in alias_rows.items()
                    ]
                    tool_command = (
                        f"{support_root}/.venv/bin/python -m "
                        "cobol_archaeologist.eval.codex_tool"
                    )
                    prompt = build_agent_prompt(
                        visible,
                        tool_command=tool_command,
                    )
                    execution = execute_codex_task(
                        prompt=prompt,
                        schema=strict_codex_schema(CodexBatchEnvelope),
                        sources={
                            alias: materialized[row.instance_id]
                            for alias, row in alias_rows.items()
                        },
                        support_root=support_root,
                        distro=distro,
                        codex_binary=codex_binary,
                        runtime_source_sha256=commit,
                        authentication_identity_sha256=account_identity,
                    )
                    _persist_raw(
                        execution,
                        artifact_dir=artifact_dir,
                        system_id=system_id,
                        batch_index=batch_index,
                    )
                    envelope = CodexBatchEnvelope.model_validate_json(
                        execution.final_message
                    )
                    validate_agent_envelope(envelope, aliases)
                    by_alias = {result.alias: result for result in envelope.results}
                    allocations = allocate_tokens(
                        execution.parsed.usage.total_tokens,
                        len(batch) * len(AGENT_HUNTS),
                    )
                    batch_records: list[EvaluationRecord] = []
                    for row_index, (alias, row) in enumerate(alias_rows.items()):
                        source = materialized[row.instance_id]
                        with tempfile.TemporaryDirectory(
                            prefix="m4-codex-verify-"
                        ) as temp:
                            tools = _tool_layer(
                                source,
                                Path(temp),
                                regulation_search,
                            )
                            start = row_index * len(AGENT_HUNTS)
                            outcome = finalize_agent_case(
                                by_alias[alias],
                                clause=row.regulation_clause,
                                program_scope=Path(row.provenance.base_program).stem,
                                instance_id=row.instance_id,
                                logs=[
                                    log
                                    for log in execution.tool_logs
                                    if log.alias == alias
                                ],
                                tools=tools,
                                budget=AGENT_BUDGET,
                                entailer=entailer,
                                token_counts=allocations[
                                    start : start + len(AGENT_HUNTS)
                                ],
                                min_successful_observations=(
                                    MIN_AGENT_ABSTENTION_OBSERVATIONS
                                ),
                                model_id=MODEL_ID,
                            )
                        batch_records.append(
                            record_outcome(
                                row,
                                outcome,
                                system_id=system_id,
                                source_sha256=source.source_sha256,
                                key=keys[row.instance_id],
                            )
                        )
                else:
                    visible = [
                        {
                            "alias": alias,
                            "context": contexts[row.instance_id],
                        }
                        for alias, row in alias_rows.items()
                    ]
                    prompt = build_baseline_prompt(system_id, visible)
                    execution = execute_codex_task(
                        prompt=prompt,
                        schema=strict_codex_schema(CodexBaselineEnvelope),
                        sources={},
                        support_root=support_root,
                        distro=distro,
                        codex_binary=codex_binary,
                        runtime_source_sha256=commit,
                        authentication_identity_sha256=account_identity,
                    )
                    _persist_raw(
                        execution,
                        artifact_dir=artifact_dir,
                        system_id=system_id,
                        batch_index=batch_index,
                    )
                    envelope = CodexBaselineEnvelope.model_validate_json(
                        execution.final_message
                    )
                    missing_aliases = validate_baseline_envelope(
                        envelope,
                        aliases,
                        system_id=system_id,
                        retrieved_counts={
                            alias: len(
                                contexts[row.instance_id].get("retrieved_clauses", [])
                            )
                            for alias, row in alias_rows.items()
                        },
                    )
                    by_alias = {result.alias: result for result in envelope.results}
                    allocations = allocate_tokens(
                        execution.parsed.usage.total_tokens,
                        len(by_alias),
                    )
                    batch_records = []
                    returned_aliases = [alias for alias in aliases if alias in by_alias]
                    for token_count, alias in zip(
                        allocations,
                        returned_aliases,
                        strict=True,
                    ):
                        row = alias_rows[alias]
                        source = materialized[row.instance_id]
                        submitted = by_alias[alias]
                        context = _baseline_context(
                            system_id,
                            contexts[row.instance_id],
                        )
                        clause = row.regulation_clause
                        binding_error = None
                        if submitted.response.kind == "finding":
                            try:
                                clause = select_baseline_clause(
                                    system_id,
                                    submitted.clause_index,
                                    context,
                                )
                            except (TypeError, ValueError) as exc:
                                binding_error = str(exc)
                        response = bind_submitted_response(
                            submitted.response,
                            instance_id=row.instance_id,
                            clause=clause,
                            token_count=token_count,
                            prebinding_error=binding_error,
                        )
                        with tempfile.TemporaryDirectory(
                            prefix="m4-codex-verify-"
                        ) as temp:
                            tools = _tool_layer(
                                source,
                                Path(temp),
                                regulation_search,
                            )
                            batch_records.append(
                                single_shot_record(
                                    row,
                                    system_id=system_id,
                                    source_sha256=source.source_sha256,
                                    key=keys[row.instance_id],
                                    context=context,
                                    tools=tools,
                                    model_factory=lambda response=response: (
                                        _ReplayDecisionModel(response)
                                    ),
                                    entailer=entailer,
                                )
                            )
                    if missing_aliases:
                        if repair_attempt < BASELINE_BUDGET.max_contract_repairs:
                            work_queue = [
                                ([alias_rows[alias]], repair_attempt + 1)
                                for alias in missing_aliases
                            ] + work_queue
                        else:
                            batch_records.extend(
                                infrastructure_failure(
                                    alias_rows[alias],
                                    system_id=system_id,
                                    source_sha256=materialized[
                                        alias_rows[alias].instance_id
                                    ].source_sha256,
                                    key=keys[alias_rows[alias].instance_id],
                                    reason=(
                                        "Codex batch failed: response omitted "
                                        f"required alias {alias}"
                                    ),
                                )
                                for alias in missing_aliases
                            )
            except Exception as exc:  # noqa: BLE001
                budget = AGENT_BUDGET if system_id == "agent" else BASELINE_BUDGET
                if repair_attempt < budget.max_contract_repairs and len(batch) > 1:
                    work_queue = [
                        ([row], repair_attempt + 1) for row in batch
                    ] + work_queue
                    batch_records = []
                else:
                    batch_records = [
                        infrastructure_failure(
                            row,
                            system_id=system_id,
                            source_sha256=materialized[row.instance_id].source_sha256,
                            key=keys[row.instance_id],
                            reason=(f"Codex batch failed: {type(exc).__name__}: {exc}"),
                        )
                        for row in batch
                    ]

            for record in batch_records:
                stream.write(record.model_dump_json() + "\n")
                stream.flush()
                records.append(record)
            records.sort(
                key=lambda record: next(
                    index
                    for index, row in enumerate(run_rows)
                    if row.instance_id == record.instance_id
                )
            )
            _write_manifest(manifest, records, manifest_path)
            print(
                json.dumps(
                    {
                        "system": system_id,
                        "mode": mode,
                        "completed": len(records),
                        "total": len(run_rows),
                        "validity": manifest.validity.status,
                        "infrastructure_failures": len(
                            manifest.infrastructure_failures
                        ),
                    }
                ),
                flush=True,
            )
            if manifest.validity.status == "HALTED_CONTRACT_REJECTIONS":
                break
    _write_manifest(manifest, records, manifest_path)
    return records


def run_codex_ablation(
    configuration_id: str,
    *,
    mode: Literal["smoke", "full"],
    distro: str = DEFAULT_WSL_DISTRO,
    codex_binary: str = DEFAULT_CODEX_BINARY,
) -> list[EvaluationRecord]:
    """Run one committed T5.5A control/ablation on the frozen paired panel."""

    # DECISION (T5.5A): this dedicated path reuses the frozen Codex prompt,
    # staging, binding, policy, and record machinery while omitting M4's pilot
    # gate. Its own committed panel/smoke identities fail closed below.

    from cobol_archaeologist.eval.ablations import (
        CONFIGURATIONS,
        DEFINITION_PATH,
        EXPERIMENT_ID,
        OUTPUT_ROOT,
        PANEL_SEED,
        AblatedToolLayer,
        assert_definition_committed,
        assess_ablation_validity,
        load_frozen_panel,
        singleton_schema_retries,
    )

    if configuration_id not in CONFIGURATIONS:
        raise ValueError(f"unknown T5.5A configuration {configuration_id!r}")
    configuration = CONFIGURATIONS[configuration_id]
    commit = assert_definition_committed()
    panel = load_frozen_panel()
    definition = json.loads(DEFINITION_PATH.read_text(encoding="utf-8"))
    definition_identity = definition.pop("identity_sha256")
    reproduced_definition_identity = hashlib.sha256(
        json.dumps(
            definition,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode()
    ).hexdigest()
    if definition_identity != reproduced_definition_identity:
        raise ValueError("T5.5A definition identity hash mismatch")
    by_id = {row.instance_id: row for row in load_split()}
    missing = [instance_id for instance_id in panel.instance_ids if instance_id not in by_id]
    if missing:
        raise ValueError(f"T5.5A panel IDs missing from frozen v1: {missing}")
    panel_rows = [by_id[instance_id] for instance_id in panel.instance_ids]
    smoke_set = set(panel.smoke_instance_ids)
    run_rows = (
        [row for row in panel_rows if row.instance_id in smoke_set]
        if mode == "smoke"
        else panel_rows
    )
    if [row.instance_id for row in run_rows] != (
        panel.smoke_instance_ids if mode == "smoke" else panel.instance_ids
    ):
        raise ValueError("T5.5A execution order differs from the frozen panel")

    support_root = prepare_support_runtime(commit=commit, distro=distro)
    login = _check_chatgpt_login(codex_binary=codex_binary, distro=distro)
    account_identity = _wsl_chatgpt_account_sha256(distro=distro)
    version_result = _wsl([codex_binary, "--version"], distro=distro)
    _require_ok(version_result, "read Codex CLI version")
    cli_version = version_result.stdout.decode("utf-8", errors="replace").strip()
    if "ChatGPT" not in login:
        raise RuntimeError("ChatGPT Codex login check failed")

    runtime_identity = configuration.model_dump(mode="json")
    manifest = RunManifest(
        system_id=configuration_id,
        provider=PROVIDER_ID,
        model_id=MODEL_ID,
        decoding={
            "reasoning_effort": REASONING_EFFORT,
            "temperature_parameter": "not_exposed_by_codex_cli",
            "seed": None,
            "authentication": "ChatGPT",
            "codex_cli_version": cli_version,
            "batch_size": AGENT_BATCH_SIZE,
            "min_successful_observations_by_drift_type": dict(EVIDENCE_MINIMUMS),
            "ablation_runtime": runtime_identity,
        },
        budgets=AGENT_BUDGET.model_dump(mode="json"),
        repository_commit=commit,
        input_revision=INPUT_REVISION,
        tool_version=f"{TOOL_VERSION}@{commit}:t5.5a:{configuration_id}",
        prompt_version=PROMPT_VERSION,
        split_path=SPLIT.relative_to(ROOT).as_posix(),
        split_sha256=hashlib.sha256(SPLIT.read_bytes()).hexdigest(),
        schema_version=SCHEMA_VERSION,
        run_mode=mode,
        smoke_rows=len(run_rows) if mode == "smoke" else None,
        smoke_seed=PANEL_SEED,
        smoke_instance_ids=list(panel.smoke_instance_ids),
        total=len(run_rows),
        experiment_id=EXPERIMENT_ID,
        configuration_id=configuration_id,
        definition_sha256=definition_identity,
        panel_identity_sha256=panel.identity_sha256,
        panel_instance_ids=list(panel.instance_ids),
    )
    configuration_root = OUTPUT_ROOT / configuration_id
    artifact_dir = configuration_root / "smoke" if mode == "smoke" else configuration_root
    records_path = artifact_dir / "agent.jsonl"
    manifest_path = artifact_dir / "agent.manifest.json"

    if mode == "full":
        smoke_path = configuration_root / "smoke" / "agent.manifest.json"
        if not smoke_path.exists():
            raise RuntimeError(f"full T5.5A run requires smoke manifest {smoke_path}")
        smoke_manifest = RunManifest.model_validate_json(
            smoke_path.read_text(encoding="utf-8")
        )
        identity_fields = (
            "system_id",
            "provider",
            "model_id",
            "decoding",
            "budgets",
            "repository_commit",
            "input_revision",
            "tool_version",
            "prompt_version",
            "split_path",
            "split_sha256",
            "schema_version",
            "smoke_seed",
            "smoke_instance_ids",
            "experiment_id",
            "configuration_id",
            "definition_sha256",
            "panel_identity_sha256",
            "panel_instance_ids",
        )
        mismatches = [
            field
            for field in identity_fields
            if getattr(smoke_manifest, field) != getattr(manifest, field)
        ]
        if (
            mismatches
            or smoke_manifest.run_mode != "smoke"
            or smoke_manifest.total != len(panel.smoke_instance_ids)
            or smoke_manifest.validity is None
            or smoke_manifest.validity.status != "VALID"
        ):
            raise RuntimeError(
                "T5.5A full-run smoke prerequisite failed"
                + (f": mismatched {mismatches}" if mismatches else "")
            )

    materialized = {row.instance_id: materialize(row) for row in run_rows}
    regulation_search = RegulationSearch(mode=configuration.regulation_search_mode)
    entailer = default_entailer()
    existing = _load_existing(records_path)
    records: list[EvaluationRecord] = []
    pending: list[DriftInstance] = []
    keys: dict[str, str] = {}
    for row in run_rows:
        source = materialized[row.instance_id]
        key = run_key(
            instance_id=row.instance_id,
            source_sha256=source.source_sha256,
            system_id=f"agent:{configuration_id}",
            model_id=MODEL_ID,
            budgets=manifest.budgets,
            prompt_version=PROMPT_VERSION,
            tool_version=manifest.tool_version,
            commit=commit,
            schema_version=SCHEMA_VERSION,
        )
        keys[row.instance_id] = key
        if key in existing:
            records.append(existing[key])
        else:
            pending.append(row)

    def write_manifest() -> None:
        records.sort(key=lambda record: panel.instance_ids.index(record.instance_id))
        manifest.completed_run_keys = sorted(record.run_key for record in records)
        manifest.infrastructure_failures = {
            record.instance_id: record.infrastructure_error
            for record in records
            if record.infrastructure_error
        }
        manifest.validity = assess_ablation_validity(records, expected_rows=len(run_rows))
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(
            manifest.model_dump_json(indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )

    write_manifest()
    records_path.parent.mkdir(parents=True, exist_ok=True)
    with records_path.open("a", encoding="utf-8", newline="\n") as stream:
        work_queue = [(batch, 0) for batch in _chunks(pending, AGENT_BATCH_SIZE)]
        batch_index = 0
        while work_queue:
            batch, repair_attempt = work_queue.pop(0)
            batch_index += 1
            aliases = [f"drift_{900000 + index:06d}" for index in range(len(batch))]
            alias_rows = dict(zip(aliases, batch, strict=True))
            batch_records: list[EvaluationRecord] = []
            try:
                visible = [
                    {
                        "alias": alias,
                        "program_scope": Path(row.provenance.base_program).stem,
                        "clause": row.regulation_clause.model_dump(mode="json"),
                    }
                    for alias, row in alias_rows.items()
                ]
                tool_command = (
                    f"{support_root}/.venv/bin/python -m "
                    "cobol_archaeologist.eval.codex_tool"
                )
                execution = execute_codex_task(
                    prompt=build_agent_prompt(visible, tool_command=tool_command),
                    schema=strict_codex_schema(CodexBatchEnvelope),
                    sources={
                        alias: materialized[row.instance_id]
                        for alias, row in alias_rows.items()
                    },
                    support_root=support_root,
                    distro=distro,
                    codex_binary=codex_binary,
                    runtime_source_sha256=commit,
                    authentication_identity_sha256=account_identity,
                    ablation_runtime=runtime_identity,
                )
                _persist_raw(
                    execution,
                    artifact_dir=artifact_dir,
                    system_id="agent",
                    batch_index=batch_index,
                )
                envelope = CodexBatchEnvelope.model_validate_json(execution.final_message)
                validate_agent_envelope(envelope, aliases)
                by_alias = {result.alias: result for result in envelope.results}
                allocations = allocate_tokens(
                    execution.parsed.usage.total_tokens,
                    len(batch) * len(AGENT_HUNTS),
                )
                for row_index, (alias, row) in enumerate(alias_rows.items()):
                    source = materialized[row.instance_id]
                    with tempfile.TemporaryDirectory(prefix="t5.5a-codex-verify-") as temp:
                        base_tools = _tool_layer(
                            source,
                            Path(temp),
                            regulation_search,
                        )
                        tools = AblatedToolLayer(base_tools, configuration.disabled_tools)
                        start = row_index * len(AGENT_HUNTS)
                        outcome = finalize_agent_case(
                            by_alias[alias],
                            clause=row.regulation_clause,
                            program_scope=Path(row.provenance.base_program).stem,
                            instance_id=row.instance_id,
                            logs=[log for log in execution.tool_logs if log.alias == alias],
                            tools=tools,
                            budget=AGENT_BUDGET,
                            entailer=entailer,
                            token_counts=allocations[start : start + len(AGENT_HUNTS)],
                            min_successful_observations=(
                                MIN_AGENT_ABSTENTION_OBSERVATIONS
                            ),
                            model_id=MODEL_ID,
                            execution_verification=(
                                configuration.execution_verification
                            ),
                            entailment_verification=(
                                configuration.entailment_verification
                            ),
                        )
                    batch_records.append(
                        record_outcome(
                            row,
                            outcome,
                            system_id=configuration_id,
                            source_sha256=source.source_sha256,
                            key=keys[row.instance_id],
                        )
                    )
            except Exception as exc:  # noqa: BLE001
                # Preserve the frozen M4 provider mechanism: a malformed or
                # alias-incomplete multi-row envelope is retried as singleton
                # batches. The scientific response is never repaired or
                # rewritten; an invalid singleton remains infrastructure
                # failure and stops a validity smoke.
                retries = singleton_schema_retries(
                    batch,
                    repair_attempt=repair_attempt,
                    max_repairs=AGENT_BUDGET.max_contract_repairs,
                )
                if retries is not None:
                    work_queue = retries + work_queue
                    continue
                batch_records = [
                    infrastructure_failure(
                        row,
                        system_id=configuration_id,
                        source_sha256=materialized[row.instance_id].source_sha256,
                        key=keys[row.instance_id],
                        reason=f"T5.5A Codex batch failed: {type(exc).__name__}: {exc}",
                    )
                    for row in batch
                ]
            for record in batch_records:
                stream.write(record.model_dump_json() + "\n")
                stream.flush()
                records.append(record)
            write_manifest()
            if mode == "smoke" and (
                manifest.validity.infrastructure_failures
                or manifest.validity.contract_rejections
            ):
                break
    write_manifest()
    return records


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--system",
        choices=(*SYSTEM_IDS, "all"),
        default="all",
    )
    parser.add_argument(
        "--mode",
        choices=("smoke", "pilot", "full"),
        default="smoke",
    )
    parser.add_argument(
        "--seed",
        type=int,
        required=True,
        help=(
            f"predeclared config-2 smoke seed; the frozen value is {CONFIG2_SMOKE_SEED}"
        ),
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    rows = load_split()
    entailer = default_entailer()
    systems = SYSTEM_IDS if args.system == "all" else (args.system,)
    for system_id in systems:
        run_codex_system(
            system_id,
            rows=rows,
            mode=args.mode,
            smoke_seed=args.seed,
            entailer=entailer,
            regulation_search=None,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
