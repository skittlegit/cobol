"""Gold-hidden orchestration primitives for T4.1."""

from __future__ import annotations

import hashlib
import json
import random
import subprocess
from collections.abc import Callable, Iterable, Sequence
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from cobol_archaeologist.agent.policy import (
    HUNT_REGISTRY,
    HuntBatchOutcome,
)
from cobol_archaeologist.agent.trajectory import BudgetSpec
from cobol_archaeologist.eval.schemas import (
    AgentHuntTrace,
    EvaluationRecord,
    RunValidity,
)
from cobol_archaeologist.model.prompt import DecisionModel
from cobol_archaeologist.model.verify import Entailer
from cobol_archaeologist.schemas import DriftInstance, RegulationClause
from cobol_archaeologist.tool_types import ToolLayer

CONFIG2_SMOKE_SEED = 20260726
CONFIG2_SMOKE_IDS: tuple[str, ...] = (
    "drift_096952",
    "drift_425267",
    "drift_110018",
    "drift_356266",
    "drift_068667",
    "drift_957679",
    "drift_858645",
)
REQUIRED_SMOKE_ROWS = len(CONFIG2_SMOKE_IDS)


def seeded_stratified_smoke(
    rows: Sequence[DriftInstance],
    *,
    seed: int,
) -> list[DriftInstance]:
    """Select one reproducible row per drift class for config-2 smoke."""

    by_drift_type: dict[str, list[DriftInstance]] = {}
    for row in rows:
        by_drift_type.setdefault(row.drift_type, []).append(row)
    if len(by_drift_type) != REQUIRED_SMOKE_ROWS:
        raise ValueError(
            "config-2 smoke requires exactly one stratum for each of seven "
            f"drift types; found {len(by_drift_type)}"
        )

    generator = random.Random(seed)
    selected = [
        generator.choice(
            sorted(by_drift_type[drift_type], key=lambda row: row.instance_id)
        )
        for drift_type in sorted(by_drift_type)
    ]
    generator.shuffle(selected)
    return selected


class SystemContext(BaseModel):
    """The complete benchmark context visible to the system under test."""

    model_config = ConfigDict(extra="forbid")

    clause: RegulationClause
    program_scope: str
    question: str


class RunManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    system_id: str
    provider: str = ""
    model_id: str
    decoding: dict = Field(default_factory=dict)
    budgets: dict = Field(default_factory=dict)
    repository_commit: str
    input_revision: str = ""
    tool_version: str = ""
    prompt_version: str
    split_path: str
    split_sha256: str = ""
    schema_version: str = "2"
    run_mode: Literal["smoke", "full", "pilot"] = "full"
    smoke_rows: int | None = Field(default=None, ge=1)
    smoke_seed: int | None = None
    smoke_instance_ids: list[str] = Field(default_factory=list)
    total: int
    completed_run_keys: list[str] = Field(default_factory=list)
    infrastructure_failures: dict[str, str] = Field(default_factory=dict)
    validity: RunValidity | None = None
    experiment_id: str | None = None
    configuration_id: str | None = None
    definition_sha256: str | None = None
    panel_identity_sha256: str | None = None
    panel_instance_ids: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _run_mode_shape(self) -> RunManifest:
        if self.run_mode == "smoke":
            if self.smoke_rows is None or self.smoke_rows != self.total:
                raise ValueError("a smoke manifest requires smoke_rows == total")
        elif self.smoke_rows is not None:
            raise ValueError("smoke_rows is valid only for a smoke manifest")
        if (self.smoke_seed is None) != (not self.smoke_instance_ids):
            raise ValueError(
                "smoke_seed and smoke_instance_ids must be recorded together"
            )
        if len(set(self.smoke_instance_ids)) != len(self.smoke_instance_ids):
            raise ValueError("smoke_instance_ids must be unique")
        if (
            self.run_mode == "smoke"
            and self.smoke_instance_ids
            and len(self.smoke_instance_ids) != self.total
        ):
            raise ValueError(
                "a smoke manifest's smoke_instance_ids must match its total"
            )
        if self.validity is not None and self.validity.completed_rows > self.total:
            raise ValueError("validity cannot report more rows than the manifest total")
        experiment_fields = (
            self.configuration_id,
            self.definition_sha256,
            self.panel_identity_sha256,
        )
        if self.experiment_id is None:
            if any(value is not None for value in experiment_fields) or self.panel_instance_ids:
                raise ValueError("supplemental identity requires experiment_id")
        else:
            if any(value is None for value in experiment_fields):
                raise ValueError("supplemental manifests require complete identity fields")
            if len(self.panel_instance_ids) != len(set(self.panel_instance_ids)):
                raise ValueError("panel_instance_ids must be unique")
        return self


def build_system_context(gold: DriftInstance) -> SystemContext:
    program_scope = Path(gold.provenance.base_program).stem
    return SystemContext(
        clause=gold.regulation_clause,
        program_scope=program_scope,
        question=(
            "Investigate whether the supplied program complies with "
            f"{gold.regulation_clause.doc} {gold.regulation_clause.clause_id}."
        ),
    )


def repository_commit(root: Path) -> str:
    return subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=root,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()


def run_key(
    *,
    instance_id: str,
    source_sha256: str,
    system_id: str,
    model_id: str,
    budgets: dict,
    prompt_version: str,
    tool_version: str,
    commit: str,
    schema_version: str = "3",
) -> str:
    payload = json.dumps(
        {
            "instance_id": instance_id,
            "source_sha256": source_sha256,
            "system_id": system_id,
            "model_id": model_id,
            "budgets": budgets,
            "prompt_version": prompt_version,
            "tool_version": tool_version,
            "commit": commit,
            "schema_version": schema_version,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode()).hexdigest()


def investigate_all_hunts(
    context: SystemContext,
    *,
    tools: ToolLayer,
    model_factory: Callable[[], DecisionModel],
    budget: BudgetSpec | None = None,
    entailer: Entailer | None = None,
    min_successful_observations_before_abstention: int = 1,
) -> HuntBatchOutcome:
    """Run every registered class hunt without revealing which class is gold."""

    outcomes = []
    for hunt in HUNT_REGISTRY.values():
        outcome = hunt.run(
            clause=context.clause,
            tools=tools,
            model=model_factory(),
            program_scope=context.program_scope,
            budget=budget,
            entailer=entailer,
            min_successful_observations_before_abstention=(
                min_successful_observations_before_abstention
            ),
        )
        reason = outcome.abstention_reason or ""
        if reason.startswith(
            ("model response unavailable:", "verification unavailable;")
        ):
            raise RuntimeError(reason)
        outcomes.append(outcome)
    findings = [outcome for outcome in outcomes if not outcome.abstained]
    if findings:
        selected = max(
            findings,
            key=lambda outcome: (
                outcome.confidence or 0.0,
                -int(outcome.verification_tier),
                outcome.hunt,
            ),
        )
    else:
        selected = outcomes[0]
    return HuntBatchOutcome(outcomes=outcomes, selected=selected)


def record_outcome(
    gold: DriftInstance,
    outcome: HuntBatchOutcome,
    *,
    system_id: str,
    source_sha256: str,
    key: str,
) -> EvaluationRecord:
    selected = outcome.selected
    return EvaluationRecord(
        instance_id=gold.instance_id,
        gold=gold,
        prediction=selected.finding,
        confidence=selected.confidence,
        verification=selected.verification,
        trajectory=selected.trajectory,
        agent_hunts=[
            AgentHuntTrace(
                hunt=item.hunt,
                selected=item == selected,
                finding=item.finding,
                confidence=item.confidence,
                verification=item.verification,
                verification_tier=item.verification_tier,
                trajectory=item.trajectory,
                abstained=item.abstained,
                abstention_reason=item.abstention_reason,
            )
            for item in outcome.outcomes
        ],
        abstained=selected.abstained,
        abstention_reason=selected.abstention_reason,
        system_id=system_id,
        source_sha256=source_sha256,
        run_key=key,
    )


def assess_run_validity(
    records: Iterable[EvaluationRecord],
    *,
    system_id: str,
) -> RunValidity:
    """Compute frozen schema-v3 validity gates from persisted evidence."""

    completed = list(records)
    available = [record for record in completed if not record.infrastructure_error]
    infrastructure_failures = len(completed) - len(available)
    trajectories = []
    for record in available:
        if system_id == "agent" and record.agent_hunts:
            trajectories.extend(trace.trajectory for trace in record.agent_hunts)
        elif record.trajectory is not None:
            trajectories.append(record.trajectory)

    responses = [
        response
        for trajectory in trajectories
        for response in trajectory.model_responses
    ]
    provider_turns = len(responses)
    contract_rejections = sum(
        response.contract_error is not None for response in responses
    )
    contract_rate = contract_rejections / provider_turns if provider_turns else 0.0
    predictions = sum(record.prediction is not None for record in available)
    prediction_rate = predictions / len(available) if available else 0.0

    successful_tools: int | None = None
    mean_successful_tools: float | None = None
    if system_id == "agent":
        successful_tools = sum(
            call.error is None and bool(call.observation_summary)
            for trajectory in trajectories
            for call in trajectory.steps
        )
        mean_successful_tools = successful_tools / len(available) if available else 0.0

    failed_gates: list[str] = []
    if infrastructure_failures:
        failed_gates.append(
            f"{infrastructure_failures} infrastructure failure(s); zero required"
        )
    if provider_turns >= 5 and contract_rate > 0.10:
        failed_gates.append(
            "contract rejection rate exceeds 0.10 after at least five "
            "provider responses"
        )
    if (
        system_id == "agent"
        and mean_successful_tools is not None
        and mean_successful_tools < 1.0
    ):
        failed_gates.append(
            "agent mean successful tool observations per available row is below 1.0"
        )
    if prediction_rate == 0.0:
        failed_gates.append("final non-null verified prediction rate is 0.0")

    if provider_turns >= 5 and contract_rate > 0.10:
        status = "HALTED_CONTRACT_REJECTIONS"
    elif infrastructure_failures:
        status = "NOT_EVALUABLE"
    elif (
        system_id == "agent"
        and mean_successful_tools is not None
        and mean_successful_tools < 1.0
    ):
        status = "INVALID_AGENT_RUN"
    elif prediction_rate == 0.0:
        status = "NOT_EVALUABLE"
    else:
        status = "VALID"

    return RunValidity(
        completed_rows=len(completed),
        available_rows=len(available),
        infrastructure_failures=infrastructure_failures,
        provider_turns=provider_turns,
        contract_rejections=contract_rejections,
        contract_rejection_rate=contract_rate,
        non_null_predictions=predictions,
        non_null_prediction_rate=prediction_rate,
        successful_tool_observations=successful_tools,
        mean_successful_tool_observations=mean_successful_tools,
        status=status,
        failed_gates=failed_gates,
    )


def infrastructure_failure(
    gold: DriftInstance,
    *,
    system_id: str,
    source_sha256: str,
    key: str,
    reason: str,
) -> EvaluationRecord:
    return EvaluationRecord(
        instance_id=gold.instance_id,
        gold=gold,
        abstained=False,
        infrastructure_error=reason,
        system_id=system_id,
        source_sha256=source_sha256,
        run_key=key,
    )


class EvaluationRunner:
    """Append-only, run-key-resumable evaluation record writer."""

    def __init__(self, records_path: Path, manifest_path: Path) -> None:
        self.records_path = Path(records_path)
        self.manifest_path = Path(manifest_path)

    def _existing(self) -> dict[str, EvaluationRecord]:
        if not self.records_path.exists():
            return {}
        records = [
            EvaluationRecord.model_validate_json(line)
            for line in self.records_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        by_key = {record.run_key: record for record in records}
        if len(by_key) != len(records):
            raise ValueError("evaluation artifact contains duplicate run keys")
        return by_key

    def _write_manifest(
        self,
        manifest: RunManifest,
        completed: Sequence[EvaluationRecord],
    ) -> None:
        manifest.completed_run_keys = sorted(record.run_key for record in completed)
        manifest.infrastructure_failures = {
            record.instance_id: record.infrastructure_error
            for record in completed
            if record.infrastructure_error
        }
        manifest.validity = assess_run_validity(
            completed,
            system_id=manifest.system_id,
        )
        self.manifest_path.parent.mkdir(parents=True, exist_ok=True)
        self.manifest_path.write_text(
            manifest.model_dump_json(indent=2),
            encoding="utf-8",
        )

    def run(
        self,
        gold_rows: Iterable[DriftInstance],
        *,
        manifest: RunManifest,
        key_factory: Callable[[DriftInstance], str],
        executor: Callable[[DriftInstance, SystemContext, str], EvaluationRecord],
    ) -> list[EvaluationRecord]:
        rows = list(gold_rows)
        if manifest.total != len(rows):
            raise ValueError("manifest total does not match requested rows")
        existing = self._existing()
        self.records_path.parent.mkdir(parents=True, exist_ok=True)
        completed: list[EvaluationRecord] = []
        # DECISION (X5): persist the predeclared seed and selected row IDs
        # before any provider-facing executor can observe or score the sample.
        self._write_manifest(manifest, completed)
        with self.records_path.open("a", encoding="utf-8", newline="\n") as stream:
            for gold in rows:
                key = key_factory(gold)
                if key in existing:
                    completed.append(existing[key])
                    validity = assess_run_validity(
                        completed,
                        system_id=manifest.system_id,
                    )
                    if validity.status == "HALTED_CONTRACT_REJECTIONS":
                        break
                    continue
                record = executor(gold, build_system_context(gold), key)
                if record.run_key != key:
                    raise ValueError("executor returned a mismatched run key")
                stream.write(record.model_dump_json() + "\n")
                stream.flush()
                existing[key] = record
                completed.append(record)
                validity = assess_run_validity(
                    completed,
                    system_id=manifest.system_id,
                )
                if validity.status == "HALTED_CONTRACT_REJECTIONS":
                    break
        self._write_manifest(manifest, completed)
        return completed
