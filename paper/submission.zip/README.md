# Anonymous submission documents

Open [the manuscript](paper/manuscript.html) and [numerical appendix](paper/numbers.html). The [claim map](paper/claim-map.json) binds every numerical claim to canonical source hashes and JSON pointers. Sanitized reports under evidence preserve all 4,492 audited numerical claims. Host paths, provider transcripts and credentials are excluded.

The source software archive is distributed separately with its original licenses and attribution. release/two-builds.json identifies its measured hash and source commit; it is not embedded in this anonymous document package. Final paper artifacts follow the archive source revision and are not claimed byte-identical to its draft paper. LICENSE here is a document review notice, not a replacement software license.
